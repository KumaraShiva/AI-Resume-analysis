from flask import Flask, render_template, request
import os
from resume_parser import extract_text_from_pdf, analyze_resume

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    extracted_text = ''
    score = None
    suggestions = []
    if request.method == 'POST':
        uploaded_file = request.files['resume']
        if uploaded_file.filename.endswith('.pdf'):
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], uploaded_file.filename)
            uploaded_file.save(filepath)
            extracted_text = extract_text_from_pdf(filepath)
            score, suggestions = analyze_resume(extracted_text)
    return render_template('index.html', text=extracted_text, score=score, suggestions=suggestions)

if __name__ == '__main__':
    app.run(debug=True)