import pdfplumber
import spacy

nlp = spacy.load("en_core_web_sm")

def extract_text_from_pdf(filepath):
    text = ''
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted + '\n'
    return text

def analyze_resume(text):
    doc = nlp(text)
    score = 0
    suggestions = []

    if 'education' in text.lower():
        score += 20
    else:
        suggestions.append("Add an Education section.")

    if 'experience' in text.lower():
        score += 20
    else:
        suggestions.append("Include your work Experience.")

    if 'skills' in text.lower():
        score += 20
    else:
        suggestions.append("List your Skills clearly.")

    if len(doc.ents) > 10:
        score += 20
    else:
        suggestions.append("Add more specific details, such as dates, orgs, or locations.")

    if len(text) > 1000:
        score += 20
    else:
        suggestions.append("Expand the resume with more relevant information.")

    return score, suggestions